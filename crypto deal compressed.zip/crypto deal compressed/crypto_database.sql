-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2021 at 01:43 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crypto_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `term` varchar(255) DEFAULT NULL,
  `signup` varchar(255) DEFAULT NULL,
  `country` text NOT NULL,
  `wallet` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `_id`, `name`, `email`, `password`, `term`, `signup`, `country`, `wallet`) VALUES
(2, 'a997c6b0bcebb83468d1c266', 'Admin', 'admin1@gmail.com', '$2a$10$ll28yMirEwWrJT0SV8vjd.6cD9BlOfPnCLFQy0axe0ph578I4XeKO', 'on', '', 'Afghanistan', 'sbkdbsjdbskjbdjskbdkjsbdjsbdsjbdjsbdkjsbdksj');

-- --------------------------------------------------------

--
-- Table structure for table `deposit_history`
--

CREATE TABLE `deposit_history` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `transaction_ref` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `owner` text NOT NULL,
  `bonus_type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `deposit_history`
--

INSERT INTO `deposit_history` (`id`, `_id`, `date`, `amount`, `transaction_ref`, `email`, `status`, `owner`, `bonus_type`) VALUES
(28, '8c0b7b6b43a06cde4025efdc', 'Fri Aug 27 2021 12:29:47 AM', '500', NULL, 'user1@gmail.com', 'Success', 'a72d498f35544b2b87445388', 0),
(29, '88a72ac9cb9880b5da79815a', 'Fri Aug 27 2021 12:32:31 AM', '200', NULL, 'user1@gmail.com', 'pending', 'a72d498f35544b2b87445388', 0),
(30, '10d1aa63d7fc98b05c133196', 'Fri Aug 27 2021 12:33:02 AM', '200', NULL, 'user1@gmail.com', 'pending', 'a72d498f35544b2b87445388', 0),
(31, '546a70a7a876634f9f055138', 'Fri Aug 27 2021 12:33:40 AM', '200', NULL, 'user1@gmail.com', 'Success', 'a72d498f35544b2b87445388', 0),
(32, '890bb8f5fbd8c6aa9a171902', 'Fri Aug 27 2021 12:35:10 AM', '200', NULL, 'user1@gmail.com', 'Success', 'a72d498f35544b2b87445388', 0),
(33, 'eb044eb1d28c4918ce3eb745', 'Fri Aug 27 2021 12:38:27 AM', '300', NULL, 'user1@gmail.com', 'Success', 'a72d498f35544b2b87445388', 0),
(34, '8a968976d5d66174ba573b07', 'Fri Aug 27 2021 12:39:44 AM', '200', NULL, 'user1@gmail.com', 'Success', 'a72d498f35544b2b87445388', 0),
(35, '3a65adf80c3d6c3df15a76da', 'Fri Aug 27 2021 12:50:34 AM', '1000', NULL, 'user1@gmail.com', 'Success', 'a72d498f35544b2b87445388', 0),
(36, '8438540214087c0c7fd8da6f', 'Fri Aug 27 2021 1:15:33 AM', '500', NULL, 'user1@gmail.com', 'pending', 'a72d498f35544b2b87445388', 0);

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `transaction_ref` varchar(255) DEFAULT NULL,
  `to_wallet` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `_id`, `owner`, `date`, `amount`, `transaction_ref`, `to_wallet`, `status`) VALUES
(18, '14779bf36e8fcba67d7c0d41', 'a72d498f35544b2b87445388', 'Fri Aug 27 2021 12:46:35 AM', '100', '...', 'sbkdbsjdbskjbdjskbdkjsbdjsbdsjbdjsbdkjsbdksj', 'Success');

-- --------------------------------------------------------

--
-- Table structure for table `payment_list`
--

CREATE TABLE `payment_list` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `wallet` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `confirmed` varchar(255) DEFAULT NULL,
  `owner` text NOT NULL,
  `date` text NOT NULL,
  `color` text NOT NULL,
  `deposite_history_id` text NOT NULL,
  `plan_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_list`
--

INSERT INTO `payment_list` (`id`, `_id`, `name`, `email`, `wallet`, `amount`, `balance`, `confirmed`, `owner`, `date`, `color`, `deposite_history_id`, `plan_id`) VALUES
(20, '6b9ce6c8089af2f76ce4c43a', 'user1', 'user1@gmail.com', 'sbkdbsjdbskjbdjskbdkjsbdjsbdsjbdjsbdkjsbdksj', '500', '500', 'true', 'a72d498f35544b2b87445388', 'Fri Aug 27 2021 12:29:47 AM', 'green', '8c0b7b6b43a06cde4025efdc', 20),
(21, '1d8b70b82cfc3125f5bf00e3', 'user1', 'user1@gmail.com', 'sbkdbsjdbskjbdjskbdkjsbdjsbdsjbdjsbdkjsbdksj', '200', '500', 'false', 'a72d498f35544b2b87445388', 'Fri Aug 27 2021 12:32:31 AM', '#f79595', '88a72ac9cb9880b5da79815a', 20),
(22, '3d08be47abc5a59aba67f25b', 'user1', 'user1@gmail.com', 'sbkdbsjdbskjbdjskbdkjsbdjsbdsjbdjsbdkjsbdksj', '200', '500', 'false', 'a72d498f35544b2b87445388', 'Fri Aug 27 2021 12:33:02 AM', '#f79595', '10d1aa63d7fc98b05c133196', 20),
(23, 'f5bef4a73ccb26ba0bef27e6', 'user1', 'user1@gmail.com', 'sbkdbsjdbskjbdjskbdkjsbdjsbdsjbdjsbdkjsbdksj', '200', '700', 'true', 'a72d498f35544b2b87445388', 'Fri Aug 27 2021 12:33:40 AM', 'green', '546a70a7a876634f9f055138', 20),
(24, 'e8249e32f5e7887cccd007b3', 'user1', 'user1@gmail.com', 'sbkdbsjdbskjbdjskbdkjsbdjsbdsjbdjsbdkjsbdksj', '200', '900', 'true', 'a72d498f35544b2b87445388', 'Fri Aug 27 2021 12:35:10 AM', 'green', '890bb8f5fbd8c6aa9a171902', 20),
(25, '9f7cc338a7a91874cf445173', 'user1', 'user1@gmail.com', 'sbkdbsjdbskjbdjskbdkjsbdjsbdsjbdjsbdkjsbdksj', '300', '300', 'true', 'a72d498f35544b2b87445388', 'Fri Aug 27 2021 12:38:27 AM', 'green', 'eb044eb1d28c4918ce3eb745', 20),
(26, 'bd9959262e59a214e956b91c', 'user1', 'user1@gmail.com', 'sbkdbsjdbskjbdjskbdkjsbdjsbdsjbdjsbdkjsbdksj', '200', '500', 'true', 'a72d498f35544b2b87445388', 'Fri Aug 27 2021 12:39:44 AM', 'green', '8a968976d5d66174ba573b07', 20),
(27, '3c61329dfb2333c1ed03e007', 'user1', 'user1@gmail.com', 'sbkdbsjdbskjbdjskbdkjsbdjsbdsjbdjsbdkjsbdksj', '1000', '1400', 'true', 'a72d498f35544b2b87445388', 'Fri Aug 27 2021 12:50:34 AM', 'green', '3a65adf80c3d6c3df15a76da', 40),
(28, 'c4c712ff23ad065dd6c3e395', 'user1', 'user1@gmail.com', 'sbkdbsjdbskjbdjskbdkjsbdjsbdsjbdjsbdkjsbdksj', '500', '1400', 'false', 'a72d498f35544b2b87445388', 'Fri Aug 27 2021 1:15:33 AM', '#f79595', '8438540214087c0c7fd8da6f', 40);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `term` varchar(255) DEFAULT NULL,
  `signup` varchar(255) DEFAULT NULL,
  `country` text NOT NULL,
  `wallet` text NOT NULL,
  `balance` text NOT NULL,
  `bonus` text NOT NULL,
  `ref_points` text NOT NULL,
  `ref_counter` text NOT NULL,
  `date` text NOT NULL,
  `ref_code` text NOT NULL,
  `phone_number` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `_id`, `name`, `email`, `password`, `term`, `signup`, `country`, `wallet`, `balance`, `bonus`, `ref_points`, `ref_counter`, `date`, `ref_code`, `phone_number`) VALUES
(7, 'a72d498f35544b2b87445388', 'user1', 'user1@gmail.com', '$2a$10$u8RdhBVYU8g/cTIdg6GCwe7MMwPDHzoMiowIM6uGvlhBEOXOK7zpS', 'on', '', 'Central African Republic', 'sbkdbsjdbskjbdjskbdkjsbdjsbdsjbdjsbdkjsbdksj', '1400', '49900', '0', '0', '8/10/2021', 'user1cc7d954ada', '');

-- --------------------------------------------------------

--
-- Table structure for table `withdrawal_list`
--

CREATE TABLE `withdrawal_list` (
  `id` int(11) NOT NULL,
  `_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `wallet` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `balance` varchar(255) DEFAULT NULL,
  `confirmed` varchar(255) DEFAULT NULL,
  `owner` text NOT NULL,
  `date` text NOT NULL,
  `color` text NOT NULL,
  `deposite_history_id` text NOT NULL,
  `plan_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `withdrawal_list`
--

INSERT INTO `withdrawal_list` (`id`, `_id`, `name`, `email`, `wallet`, `amount`, `balance`, `confirmed`, `owner`, `date`, `color`, `deposite_history_id`, `plan_id`) VALUES
(18, 'bacf7e4473e46bd83b7f59e6', 'user1', 'user1@gmail.com', 'sbkdbsjdbskjbdjskbdkjsbdjsbdsjbdjsbdkjsbdksj', '100', '400', 'true', 'a72d498f35544b2b87445388', 'Fri Aug 27 2021 12:46:35 AM', 'green', '14779bf36e8fcba67d7c0d41', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deposit_history`
--
ALTER TABLE `deposit_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_list`
--
ALTER TABLE `payment_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdrawal_list`
--
ALTER TABLE `withdrawal_list`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `deposit_history`
--
ALTER TABLE `deposit_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `payment_list`
--
ALTER TABLE `payment_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `withdrawal_list`
--
ALTER TABLE `withdrawal_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
