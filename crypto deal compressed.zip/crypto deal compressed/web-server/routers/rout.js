const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken')
const auth = require('./auth')
const multer = require('multer');
const path = require('path');
const mysql = require('mysql');
const crypto = require('crypto')
const nodemailer = require('nodemailer');
const os = require('os')

const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})

// Bitcoin 1LoofSzsnnbf2vMzuQ1Y­dNj7AcXm8W3uKL
// Theruem 0xF1255128Bd78a2c45A­B82D8129a4E0D41d043F­4c

// username: hackdper
// password: k1mOJtqguDiI

db.connect((error) => {
    if (error) {
        console.log(error)
    }
    console.log('SQL Connected')
})


// @ set up validation for image upload
const storage = multer.diskStorage({
    destination: './web-server/web-folder/public/webStorage/avatar',
    filename: function (req, file, cb) {
        cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
    }
})
const upload = multer({
    // limits: 300000,
    storage: storage
})

// Sample routers 
router.get('/guessHome', (req, res) => {
    res.render('home')
})

router.get('/aboutus', (req, res) => {
    res.render('aboutus')
})
router.get('/policy', (req, res) => {
    res.render('policy')
})

router.get('/', (req, res) => {
    const token = req.cookies.auth_token
    if (token) {
        return res.redirect('/home')
    }

    res.redirect('/guessHome')
})
// Login routes
router.get('/login', (req, res) => {
    res.render('form/login')
})

router.post('/login', async (req, res) => {
    async function findEmail() {
        return new Promise((resolve, reject) => {
            let sql = `SELECT * FROM users WHERE email='${req.body.email.toLowerCase()}'`
            db.query(sql, (error, result) => {
                if (error) {
                    return res.render('form/login', {
                        err: 'Email could not be found',
                        email: req.body.email
                    })
                }
                resolve(result)
            })
        })
    }

    const email = await findEmail()
    let user = email[0]
    // console.log(user)

    // @ id no user found
    if (email.length == 0) {
        return res.render('form/login', {
            err: 'Email could not be found',
            email: req.body.email
        })
    }

    // Compare password
    const verifyUser = await bcrypt.compare(req.body.password, user.password);
    if (!verifyUser) {
        return res.render('form/login', {
            err: 'Password is incorrect',
            email: req.body.email
        })
    }


    // Send token to header 
    const token = await jwt.sign({ _id: user._id }, process.env.JWT_SECRET);
    // Send cookie
    res.cookie('auth_token', token)
    req.session.save()
    res.redirect('/home')
})



router.get('/signup', (req, res) => {
    res.render('form/signup')
})

router.post('/createAccount', async (req, res) => {
    const _id = crypto.randomBytes(12).toString('hex')
    const hashPassword = await bcrypt.hash(req.body.password, 10);

    let data = {
        _id,
        ...req.body,
        password: hashPassword,
        bonus: 0,
        balance: 0,
        ref_points: 0,
        ref_counter: 0,
        date: new Date().toLocaleDateString(),
        ref_code: req.body.name.substr(0, 5) + crypto.randomBytes(5).toString('hex')
    }

    let sql = 'INSERT INTO users SET ?'

    db.query(sql, data, (error) => {
        if (error) {
            return console.log(error)
        }
        console.log('Created a new User')
    })

    // Send token to header 
    const token = await jwt.sign({ _id: data._id }, process.env.JWT_SECRET);
    res.cookie('auth_token', token)
    req.session.save()
    res.redirect('/home')
})

router.get('/home', auth, async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    user = user[0]

    let totalArr = []
    let withdraw_history = await SQLQUERY(`SELECT * FROM history WHERE owner='${req.user._id}' ORDER BY id DESC`)
    
    if (withdraw_history.length != 0) {
        for (i = 0; i < withdraw_history.length; i++) {
            totalArr.push(withdraw_history[i].amount)
        }
        totalArr = totalArr.map(val => parseInt(val)).reduce((a, b) => a + b)
    }

    res.render('index', {
        user,
        totalArr
    })
})

// About page
router.get('/profile', auth, async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    user = user[0]
    res.render('my-account', {
        user
    })
})

// Edit routs
router.get('/edit', auth, async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    user = user[0]
    res.render('account-settings', {
        user
    })
})

router.post('/editprofile', auth, async (req, res) => {
    let sql = `UPDATE users SET phone_number='${req.body.phone_number}', name='${req.body.name}',wallet='${req.body.wallet}'  WHERE _id='${req.user._id}'`
    db.query(sql, (error) => {
        if (error) {
            return console.log(error)
        }
    })
    res.redirect('/edit')
})

// Update password
router.post('/updatePassword', auth, async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    user = user[0]

    const checkPassword = await bcrypt.compare(req.body.password, user.password)
    console.log(req.body)
    if (!checkPassword) {
        res.render('account-settings', {
            user,
            errorWrong: 'Your old password is incorrect'
        })
        return
    }

    if (req.body.passwordConfirm !== req.body.password) {
        res.render('account-settings', {
            user,
            passError: 'Old password did not match with new password'
        })
        return
    }

    let password = await bcrypt.hash(req.body.password, 10)

    let sql = `UPDATE users SET password='${password}'  WHERE _id='${req.user._id}'`
    db.query(sql, (error) => {
        if (error) {
            return console.log(error)
        }
    })

    res.redirect('/edit')


})


// Buy starter plans
router.get('/plans', auth, async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    user = user[0]
    res.render('pricing', {
        user
    })
})

router.get('/bookPrice', auth, async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    user = user[0]
    res.render('pricing-details', {
        user
    })
})
router.get('/bookPrice2', auth, async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    user = user[0]
    res.render('pricing-details2', {
        user
    })
})
router.get('/bookPrice3', auth, async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    user = user[0]
    res.render('pricing-details3', {
        user
    })
})

router.post('/pickPrice', auth, async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    user = user[0]

    const _id = crypto.randomBytes(12).toString('hex')
    let data = {
        _id,
        ...req.body,
        owner: req.user._id,
        date: new Date().toDateString() + ' ' + new Date().toLocaleTimeString(),
        email: user.email,
        status: 'pending'
    }

    delete data.plan_id
    delete data.poption
    delete data.payarena

    db.query('INSERT INTO deposit_history SET ?', data, (error) => {
        if (error) {
            return console.log(error)
        }
    })

    // Create payment list
    const _id2 = crypto.randomBytes(12).toString('hex')
    let paymentList = {
        _id: _id2,
        name: user.name,
        amount: req.body.amount,
        email: user.email,
        balance: user.balance,
        confirmed: 'false',
        owner: user._id,
        color: '#f79595',
        date: new Date().toDateString() + ' ' + new Date().toLocaleTimeString(),
        wallet: user.wallet,
        deposite_history_id: data._id,
        plan_id: req.body.plan_id
    }

    db.query('INSERT INTO payment_list SET ?', paymentList, (error) => {
        if (error) {
            return console.log(error)
        }
    })


    res.redirect('/bitcoin-deposite-payment')
})



router.get('/bitcoin-deposite-payment', auth, async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    user = user[0]
    res.render('blockchain-fiesta-v2', {
        user
    })
})

// deposite router
router.get('/deposit-history', auth, async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    let deposit_history = await SQLQUERY(`SELECT * FROM deposit_history WHERE owner='${req.user._id}' ORDER BY id DESC`)
    user = user[0]
    res.render('deposit-stats', {
        user,
        deposit_history
    })
})

// withdraw router
router.get('/withdraw-history', auth, async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    user = user[0]
    let withdraw_history = await SQLQUERY(`SELECT * FROM history WHERE owner='${req.user._id}' ORDER BY id DESC`)
    res.render('withdrawal-stats', {
        user,
        withdraw_history
    })
})

router.get('/withdraw', auth, async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    user = user[0]
    res.render('withdraw-funds', {
        user
    })
})



router.post('/withdrawFunds', auth, async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    user = user[0]

    if (parseInt(req.body.amount) > parseInt(user.balance) ||
        parseInt(user.balance) < parseInt(req.body.amount ||
            parseInt(user.balance) == 0)
    ) {
        return res.send('<h1>Invalid request</h1> <br>')
    }

    // let balance = parseInt(user.balance) - parseInt(req.body.amount)
    // let sql = `UPDATE users SET balance='${balance}' WHERE _id='${req.user._id}'`
    // db.query(sql, (error) => {
    //     if (error) {
    //         return console.log(error)
    //     }
    // })

    const _id = crypto.randomBytes(12).toString('hex')
    let data = {
        _id,
        ...req.body,
        owner: req.user._id,
        date: new Date().toDateString() + ' ' + new Date().toLocaleTimeString(),
        to_wallet: user.wallet,
        transaction_ref: '...',
        status: 'pending'
    }

    delete data.submit
    db.query('INSERT INTO history SET ?', data, (error) => {
        if (error) {
            return console.log(error)
        }
    })

    // add to Admin withdrawal list
    // Create payment list
    const _id2 = crypto.randomBytes(12).toString('hex')
    let withdrawal_list = {
        _id: _id2,
        name: user.name,
        amount: req.body.amount,
        email: user.email,
        balance: user.balance,
        confirmed: 'false',
        owner: user._id,
        color: '#f79595',
        date: new Date().toDateString() + ' ' + new Date().toLocaleTimeString(),
        wallet: user.wallet,
        deposite_history_id: data._id
    }
    delete withdrawal_list.submit

    db.query('INSERT INTO withdrawal_list SET ?', withdrawal_list, (error) => {
        if (error) {
            return console.log(error)
        }
    })

    res.redirect('/home')
})

module.exports = router