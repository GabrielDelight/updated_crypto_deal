const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken')
const adminAuth = require('./adminAuth')
const multer = require('multer');
const path = require('path');
const mysql = require('mysql');
const crypto = require('crypto')
const nodemailer = require('nodemailer');
const os = require('os')

const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})

// Bitcoin 1LoofSzsnnbf2vMzuQ1Y­dNj7AcXm8W3uKL
// Theruem 0xF1255128Bd78a2c45A­B82D8129a4E0D41d043F­4c

db.connect((error) => {
    if (error) {
        console.log(error)
    }
    console.log('SQL Connected')
})


// @ set up validation for image upload
const storage = multer.diskStorage({
    destination: './web-server/web-folder/public/webStorage/avatar',
    filename: function (req, file, cb) {
        cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
    }
})


router.get('/admin-signup', (req, res) => {
    res.render('form/admin-signup')
})

router.post('/admin_signup', async (req, res) => {
    const _id = crypto.randomBytes(12).toString('hex')
    const hashPassword = await bcrypt.hash(req.body.password, 10);
    let data = {
        _id,
        ...req.body,
        password: hashPassword,
    }
    
    let sql = 'INSERT INTO admin SET ?'

    db.query(sql, data, (error) => {
        if (error) {
            return console.log(error)
        }
        console.log('Created a new User')
    })

    // Send token to header 
    const token = await jwt.sign({ _id: data._id }, 'thisfuckingsecretfuck');
    res.cookie('admin_auth', token)
    req.session.save()
    res.redirect('/admin')    
})

router.get('/admin-login', (req, res) => {
    res.render('form/admin-login')
})

router.post('/admin-login', async (req, res) => {
    async function findEmail() {
        return new Promise((resolve, reject) => {
            let sql = `SELECT * FROM admin WHERE email='${req.body.email.toLowerCase()}'`
            db.query(sql, (error, result) => {
                if (error) {
                    return res.render('form/admin-login', {
                        err: 'Email could not be found',
                        email: req.body.email
                    })
                }
                resolve(result)
            })
        })
    }

    const email = await findEmail()
    let user = email[0]
    // console.log(user)

    // @ id no user found
    if (email.length == 0) {
        return res.render('form/admin-login', {
            err: 'Email could not be found',
            email: req.body.email
        })
    }

    // Compare password
    const verifyUser = await bcrypt.compare(req.body.password, user.password);
    if (!verifyUser) {
        return res.render('form/admin-login', {
            err: 'Password is incorrect',
            email: req.body.email
        })
    }
    // Send token to header 
    const token = await jwt.sign({ _id: user._id }, 'thisfuckingsecretfuck');
    // Send cookie
    res.cookie('admin_token', token)
    req.session.save()
    res.redirect('/admin')
})


// Admin section
router.get('/admin', adminAuth, async (req, res) => {
    res.render('admin')
})

router.get('/admin-payment-approval', adminAuth, async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let payment_list = await SQLQUERY(`SELECT * FROM payment_list ORDER BY id DESC`)
    res.render('admin-payment-approval', {
        payment_list
    })
})


router.get('/confirm-payemnt/:id/:amount/:paymentList/:deposite_history_id/:plan_id', adminAuth, async (req, res) => {    
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.params.id}'`)
    user = user[0]


    let price = parseInt(req.params.amount) + parseInt(user.balance)
    let sql2 = `UPDATE users SET balance='${price}',bonus='${(req.params.amount * parseInt(req.params.plan_id)) + parseInt(user.bonus)}' WHERE _id='${req.params.id}'`
    db.query(sql2, (error) => {
        if (error) {
            return console.log(error)
        }
    })


    // @ Update the payment list to true
    let sql3 = `UPDATE payment_list SET confirmed='true', color='green', balance='${price}' WHERE _id='${req.params.paymentList}'`
    db.query(sql3, (error) => {
        if (error) {
            return console.log(error)
        }
    })

    // Update the user deposite history
    let sql4 = `UPDATE deposit_history SET status='Success' WHERE _id='${req.params.deposite_history_id}'`
    db.query(sql4, (error) => {
        if (error) {
            return console.log(error)
        }
    })

    res.redirect('/admin-payment-approval')
})





router.get('/admin-withdraw-approval', adminAuth, async (req, res) => {
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let withdrawal_list = await SQLQUERY(`SELECT * FROM withdrawal_list ORDER BY id DESC`)
    res.render('admin-withdraw-approval', {
        withdrawal_list
    })
})


router.get('/confirm-withdraw/:id/:amount/:paymentList/:deposite_history_id', adminAuth, async (req, res) => {    
    async function SQLQUERY(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    let user = await SQLQUERY(`SELECT * FROM users WHERE _id='${req.params.id}'`)
    user = user[0]

    let price = parseInt(user.balance) - parseInt(req.params.amount) 
    let newBonus = parseInt(user.bonus) - parseInt(req.params.amount) 
    let sql2 = `UPDATE users SET balance='${price}', bonus='${newBonus}' WHERE _id='${req.params.id}'`
    db.query(sql2, (error) => {
        if (error) {
            return console.log(error)
        }
    })


    // @ Update the payment list to true
    let sql3 = `UPDATE withdrawal_list SET confirmed='true', color='green', balance='${price}' WHERE _id='${req.params.paymentList}'`
    db.query(sql3, (error) => {
        if (error) {
            return console.log(error)
        }
    })

    // Update the user deposite history
    let sql4 = `UPDATE history SET status='Success' WHERE _id='${req.params.deposite_history_id}'`
    db.query(sql4, (error) => {
        if (error) {
            return console.log(error)
        }
    })

    res.redirect('/admin-withdraw-approval')
})


module.exports = router